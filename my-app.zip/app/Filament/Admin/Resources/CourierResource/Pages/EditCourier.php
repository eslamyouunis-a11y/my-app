<?php

namespace App\Filament\Admin\Resources\CourierResource\Pages;

use App\Filament\Admin\Resources\CourierResource;
use App\Models\CourierCommission;
use Filament\Resources\Pages\EditRecord;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Hash;

class EditCourier extends EditRecord
{
    protected static string $resource = CourierResource::class;

    protected function handleRecordUpdate(Model $record, array $data): Model
    {
        // بيانات User من الفورم (مش dehydrated في $data)
        $email = $this->data['email'] ?? null;
        $password = $this->data['password'] ?? null;

        // commissions
        $commissionData = $data['commission'] ?? [];
        unset($data['commission']);

        // ضمان city legacy (NOT NULL)
        if (empty($data['city']) && ! empty($data['area_id'])) {
            $data['city'] = \App\Models\Area::whereKey($data['area_id'])->value('name') ?? $record->city;
        }

        // تحديث courier
        $record->update($data);

        // تحديث/إنشاء commissions + Sync legacy columns داخل couriers
        $commission = CourierCommission::updateOrCreate(
            ['courier_id' => $record->id],
            $commissionData
        );

        $record->update([
            'delivery_fee'     => $commission->delivery_value ?? 0,
            'delivery_percent' => $commission->delivery_percentage ?? 0,
            'paid_fee'         => $commission->paid_value ?? 0,
            'paid_percent'     => $commission->paid_percentage ?? 0,
            'return_fee'       => $commission->sender_return_value ?? 0,
            'return_percent'   => $commission->sender_return_percentage ?? 0,
        ]);

        // تحديث User المرتبط
        if ($record->user) {
            if ($email && $email !== $record->user->email) {
                // منع تعارض الإيميل على users
                $exists = \App\Models\User::where('email', $email)
                    ->where('id', '!=', $record->user->id)
                    ->exists();

                if ($exists) {
                    throw new \RuntimeException('هذا البريد الإلكتروني مستخدم بالفعل.');
                }

                $record->user->email = $email;
            }

            // تحديث branch_id في user لو الفرع اتغير
            $record->user->branch_id = $record->branch_id;

            // password اختياري: لو مكتوب بس
            if (! empty($password)) {
                $record->user->password = Hash::make($password);
            }

            $record->user->save();
        }

        return $record;
    }
}
