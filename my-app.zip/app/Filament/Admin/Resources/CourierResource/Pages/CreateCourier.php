<?php

namespace App\Filament\Admin\Resources\CourierResource\Pages;

use App\Filament\Admin\Resources\CourierResource;
use App\Models\Courier;
use App\Models\CourierCommission;
use App\Models\User;
use Filament\Resources\Pages\CreateRecord;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Hash;

class CreateCourier extends CreateRecord
{
    protected static string $resource = CourierResource::class;

    protected function handleRecordCreation(array $data): Model
    {
        // بيانات User
        $email = $this->data['email'] ?? null;
        $password = $this->data['password'] ?? null;

        // بيانات commissions من الفورم (relation style)
        $commissionData = $data['commission'] ?? [];
        unset($data['commission']);

        // ضمان city legacy (NOT NULL) حتى لو المستخدم ما شافها
        if (empty($data['city']) && ! empty($data['area_id'])) {
            $data['city'] = \App\Models\Area::whereKey($data['area_id'])->value('name') ?? '';
        }

        // إنشاء courier
        $courier = Courier::create($data);

        // حفظ commission relation + Sync legacy columns داخل couriers
        $commission = CourierCommission::updateOrCreate(
            ['courier_id' => $courier->id],
            $commissionData
        );

        $courier->update([
            'delivery_fee'     => $commission->delivery_value ?? 0,
            'delivery_percent' => $commission->delivery_percentage ?? 0,
            'paid_fee'         => $commission->paid_value ?? 0,
            'paid_percent'     => $commission->paid_percentage ?? 0,
            'return_fee'       => $commission->sender_return_value ?? 0,
            'return_percent'   => $commission->sender_return_percentage ?? 0,
        ]);

        // إنشاء User للمندوب
        if (! $email || ! $password) {
            throw new \RuntimeException('Email/Password is required to create courier user.');
        }

        if (User::where('email', $email)->exists()) {
            throw new \RuntimeException('هذا البريد الإلكتروني مستخدم بالفعل.');
        }

        User::create([
            'name'       => $courier->full_name,
            'email'      => $email,
            'password'   => Hash::make($password),
            'courier_id' => $courier->id,
            'branch_id'  => $courier->branch_id, // موجود في users حسب DB
        ]);

        return $courier;
    }
}
