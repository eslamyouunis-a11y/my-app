<?php

namespace App\Filament\Admin\Resources\GovernorateResource\Pages;

use App\Filament\Admin\Resources\GovernorateResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateGovernorate extends CreateRecord
{
    protected static string $resource = GovernorateResource::class;
}
